  <h2>Bienvenue sur l'intranet GSB - Gestion des frais</h2>
