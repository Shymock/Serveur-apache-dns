<?php 
    echo toHTMLErreurs($tabErreurs);  
?>
