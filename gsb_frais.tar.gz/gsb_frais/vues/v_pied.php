
    <!-- Division pour le pied de page -->
    <div id="pied">
      <p class="logoValidW3c">
          <img src="http://www.w3.org/Icons/valid-xhtml10"
               alt="Valid XHTML 1.0 Strict" />
      </p>
      <p class="logoValidW3c">
          <img src="http://jigsaw.w3.org/css-validator/images/vcss"
               alt="CSS Valide !" />
      </p>
      <p id="libValidW3c">Cette page est conforme aux standards du Web</p>
    </div>
    <div class="spacer">&nbsp;</div>
   </div>

  </body>
</html>
